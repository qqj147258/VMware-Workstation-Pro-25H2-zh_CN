# 文件夹
zh_CN文件夹放入 .\VMware\VMware Workstation\messages\